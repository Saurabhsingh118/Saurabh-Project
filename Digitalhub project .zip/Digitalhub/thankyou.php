<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #e26faf, #b83ddd);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
            font-size: 32px;
        }
        p {
            color: #555;
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 30px;
        }
        .emoji {
            font-size: 48px;
            margin-bottom: 20px;
        }
        .underline {
            border-bottom: 2px solid #4CAF50;
            display: inline-block;
            margin-bottom: 20px;
        }
        .btn {
            background-color: #4CAF50;
            color: white;
            padding: 12px 24px;
            border: 2px solid #4CAF50;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 18px;
            transition: background-color 0.3s, color 0.3s, border-color 0.3s;
            display: inline-block;
        }
        .btn:hover {
            background-color: #45a049;
            border-color: #45a049;
        }
        .btn-cancel {
            background-color: #f44336;
            border-color: #f44336;
        }
        .btn-cancel:hover {
            background-color: #d32f2f;
            border-color: #d32f2f;
        }
    </style>
</head>
<body>
    <div class="container">
        <span class="emoji">🎉</span>
        <h1>Thank You for the Order!</h1>
        <div class="underline"></div>
        <p>Your order has been successfully placed. We appreciate your business and look forward to serving you again.</p>
        <a href="cancel.php" class="btn btn-cancel">Cancel Order</a> <!-- Changed to .php -->
    </div>
</body>
</html>
