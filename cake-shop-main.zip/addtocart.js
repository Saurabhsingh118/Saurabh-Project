const product = [
    {
        id: 0,
        image: 'images/deva-williamson-S2jw81lfrG0-unsplash.jpg',
        title: 'Stawberry Covered Infusion',
        price: 120,
    },
    {
        id: 1,
        image: 'images/heather-barnes-hLOLcUwR0Y4-unsplash.jpg',
        title: 'Stawberry Dessert',
        price: 60,
    },
    {
        id: 2,
        image: 'images/heather-ford-POM4KxWZcG8-unsplash.jpg',
        title: 'Butter Milk Donuts',
        price: 230,
    },
    {
        id: 3,
        image: 'images/humphrey-muleba-jABXuTS1azc-unsplash.jpg',
        title: 'Stawberry Waffle Blueberries',
        price: 100,
    },
    {
        id: 4,
        image: 'images/joyful-vT5xrj3z1OE-unsplash.jpg',
        title: 'Stawberry French Crepes',
        price: 100,
    },
    {
        id: 5,
        image: 'images/massimo-adami-mtut50xOeC4-unsplash.jpg',
        title: 'Stawberry Flavoured Cake',
        price: 100,
    },
    {
        id: 6,
        image: 'images/aa4239e32994e18ae91078f7e1a0eacf.png',
        title: 'Dark Chocolate Fudge Brownie',
        price: 100,
    },
    {
        id: 7,
        image: 'images/classic-dark-chocolate-fudge-40610.png',
        title: 'Dark Chocolate Fudge Brownie',
        price: 100,
    },
    {
        id: 8,
        image: 'images/classic-white-cake-mix-75310.webp',
        title: 'Classic White',
        price: 100,
    }
];
const categories = [...new Set(product.map((item)=>
    {return item}))]
    let i=0;
document.getElementById('root').innerHTML = categories.map((item)=>
{
    var {image, title, price} = item;
    return(
        `<div class='box'>
            <div class='img-box'>
                <img class='images' src=${image}></img>
            </div>
        <div class='bottom'>
        <p>${title}</p>
        <h2>$ ${price}.00</h2>`+
        "<button onclick='addtocart("+(i++)+")'>Buy Now</button>"+
        `</div>
        </div>`
    )
}).join('')

var cart =[];

function addtocart(a){
    cart.push({...categories[a]});
    displaycart();
}
function delElement(a){
    cart.splice(a, 1);
    displaycart();
}

function displaycart(){
    let j = 0, total=0;
    document.getElementById("count").innerHTML=cart.length;
    if(cart.length==0){
        document.getElementById('cartItem').innerHTML = "Your cart is empty";
        document.getElementById("total").innerHTML = "$ "+0+".00";
    }
    else{
        document.getElementById("cartItem").innerHTML = cart.map((items)=>
        {
            var {image, title, price} = items;
            total=total+price;
            document.getElementById("total").innerHTML = "$ "+total+".00";
            return(
                `<div class='cart-item'>
                <div class='row-img'>
                    <img class='rowimg' src=${image}>
                </div>
                <p style='font-size:12px;'>${title}</p>
                <h2 style='font-size: 15px;'>$ ${price}.00</h2>`+
                "<i class='fa-solid fa-trash' onclick='delElement("+ (j++) +")'></i></div>"
            );
        }).join('');
    }

    
}
function displaycart(){
    let j = 0, total = 0;
    document.getElementById("count").innerHTML = cart.length;
    if(cart.length === 0){
        document.getElementById('cartItem').innerHTML = "Your cart is empty";
        document.getElementById("total").innerHTML = "$ 0.00";
    }
    else {
        document.getElementById("cartItem").innerHTML = cart.map((items) => {
            var {image, title, price} = items;
            total += price;
            return (
                `<div class='cart-item'>
                    <div class='row-img'>
                        <img class='rowimg' src=${image}>
                    </div>
                    <p style='font-size:12px;'>${title}</p>
                    <h2 style='font-size: 15px;'>$ ${price}.00</h2>
                    <i class='fa-solid fa-trash' onclick='delElement(${j++})'></i>
                </div>`
            );
        }).join('');

        document.getElementById("total").innerHTML = "$ " + total.toFixed(2);
    }
}
// Function to proceed to checkout
function proceedToCheckout() {
    // Redirect to the checkout page
    window.location.href = 'checkout.html';
}
