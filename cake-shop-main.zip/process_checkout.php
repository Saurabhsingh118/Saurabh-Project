<?php
// Database connection parameters
$servername = "localhost"; // Change this to your database server name if different
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "customer"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$phoneNumber = $_POST['phoneNumber'];
$address = $_POST['address'];
$pincode = $_POST['pincode'];
$totalAmount = $_POST['totalAmount'];
$paymentMethod = implode(", ", $_POST['paymentMethod']); // Assuming payment methods are stored as an array

// Prepare SQL statement with placeholders
$sql = "INSERT INTO checkout (firstName, lastName, phoneNumber, address, pincode, totalAmount, paymentMethod)
        VALUES (?, ?, ?, ?, ?, ?, ?)";

// Prepare and bind parameters
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssiss", $firstName, $lastName, $phoneNumber, $address, $pincode, $totalAmount, $paymentMethod);

// Execute SQL statement
if ($stmt->execute()) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
